package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import com.prankzone.app.R

class LowBatteryActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var percent = 15

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_low_battery)
        setupExitGesture(findViewById(android.R.id.content))

        val txtPercent = findViewById<TextView>(R.id.txtBatteryPercent)
        tick(txtPercent)
    }

    private fun tick(txtPercent: TextView) {
        if (percent > 1) {
            percent--
            txtPercent.text = "$percent%"
            handler.postDelayed({ tick(txtPercent) }, 900)
        } else {
            txtPercent.text = "1%"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
