package com.prankzone.app.pranks

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.TextView
import com.prankzone.app.R

class SelfDestructActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var count = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_self_destruct)

        val root = findViewById<android.view.View>(R.id.rootDestruct)
        setupExitGesture(root)

        val txtCount = findViewById<TextView>(R.id.txtCountdown)
        val txtLabel = findViewById<TextView>(R.id.txtDestructLabel)
        tick(txtCount, txtLabel)
    }

    private fun tick(txtCount: TextView, txtLabel: TextView) {
        if (count > 0) {
            txtCount.text = count.toString()
            pulse()
            count--
            handler.postDelayed({ tick(txtCount, txtLabel) }, 1000)
        } else {
            txtCount.text = "😝"
            txtLabel.text = "Gotcha ! Ce n'était qu'une blague."
        }
    }

    private fun pulse() {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(120)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
