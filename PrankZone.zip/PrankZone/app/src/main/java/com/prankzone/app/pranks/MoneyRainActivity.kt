package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import com.prankzone.app.R

class MoneyRainActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val emojis = listOf("💰", "🤑", "💵", "🎉")
    private var running = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_money_rain)

        val root = findViewById<FrameLayout>(R.id.rootMoney)
        setupExitGesture(root)

        spawnLoop(root)
    }

    private fun spawnLoop(root: FrameLayout) {
        if (!running) return
        spawnCoin(root)
        handler.postDelayed({ spawnLoop(root) }, 180)
    }

    private fun spawnCoin(root: FrameLayout) {
        val coin = TextView(this)
        coin.text = emojis.random()
        coin.textSize = (24..40).random().toFloat()
        val params = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        root.addView(coin, params)

        root.post {
            val screenWidth = root.width.coerceAtLeast(200)
            coin.x = (0 until screenWidth).random().toFloat()
            coin.y = -80f
            coin.animate()
                .y(root.height.toFloat() + 80f)
                .setDuration((2200..3600).random().toLong())
                .withEndAction { root.removeView(coin) }
                .start()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        handler.removeCallbacksAndMessages(null)
    }
}
