package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.prankzone.app.R

class SmsFloodActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val fakeMessages = listOf(
        "Salut, tu fais quoi ? 😄",
        "T'as vu l'heure ?!",
        "Réponds steuplaît c'est urgent",
        "Allo ?",
        "😂😂😂😂😂",
        "Je crois que ton tel bug",
        "Pourquoi tu réponds pas",
        "URGENT !!!",
        "T'es où là",
        "Ça sonne dans le vide"
    )
    private var count = 0
    private var running = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_flood)

        val root = findViewById<android.view.View>(R.id.rootSmsFlood)
        setupExitGesture(root)

        val container = findViewById<LinearLayout>(R.id.containerMessages)
        val scroll = findViewById<ScrollView>(R.id.scrollMessages)
        val txtCounter = findViewById<TextView>(R.id.txtSmsCounter)

        addMessageLoop(container, scroll, txtCounter)
    }

    private fun addMessageLoop(container: LinearLayout, scroll: ScrollView, txtCounter: TextView) {
        if (!running) return
        val bubble = TextView(this)
        bubble.text = fakeMessages.random()
        bubble.setPadding(24, 16, 24, 16)
        bubble.setTextColor(0xFFFFFFFF.toInt())
        bubble.setBackgroundColor(0xFF2ED573.toInt())
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(16, 8, 16, 8)
        container.addView(bubble, params)

        count++
        txtCounter.text = "$count nouveaux messages"

        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }

        handler.postDelayed({ addMessageLoop(container, scroll, txtCounter) }, 450)
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        handler.removeCallbacksAndMessages(null)
    }
}
