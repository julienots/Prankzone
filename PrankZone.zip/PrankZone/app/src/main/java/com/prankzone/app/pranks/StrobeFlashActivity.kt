package com.prankzone.app.pranks

import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import androidx.core.content.ContextCompat
import android.Manifest
import com.prankzone.app.R

class StrobeFlashActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private var torchOn = false
    private var running = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_strobe_flash)
        setupExitGesture(findViewById(R.id.rootStrobe))

        val txtStatus = findViewById<TextView>(R.id.txtStrobeStatus)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            txtStatus.text = getString(R.string.permission_needed)
            return
        }

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        if (cameraId == null) {
            txtStatus.text = "Aucun flash disponible sur cet appareil"
            return
        }

        strobe()
    }

    private fun strobe() {
        if (!running) return
        val id = cameraId ?: return
        try {
            torchOn = !torchOn
            cameraManager.setTorchMode(id, torchOn)
        } catch (_: Exception) {
            // Ignore si la caméra est occupée par une autre app
        }
        handler.postDelayed({ strobe() }, 120)
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        handler.removeCallbacksAndMessages(null)
        try {
            cameraId?.let { cameraManager.setTorchMode(it, false) }
        } catch (_: Exception) {
        }
    }
}
