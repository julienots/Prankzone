package com.prankzone.app

data class Prank(
    val title: String,
    val description: String,
    val activityClass: Class<*>,
    val needsCamera: Boolean = false
)
