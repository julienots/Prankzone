package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import com.prankzone.app.R

class FakeHackActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val logLines = listOf(
        "Connexion au serveur distant...",
        "Contournement du pare-feu...",
        "Extraction des données...",
        "Déchiffrement en cours...",
        "Accès obtenu.",
        "Envoi des fichiers..."
    )
    private var lineIndex = 0
    private var countdown = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fake_hack)
        setupExitGesture(findViewById(android.R.id.content))

        val txtLog = findViewById<TextView>(R.id.txtHackLog)
        val txtCountdown = findViewById<TextView>(R.id.txtHackCountdown)

        addLine(txtLog)
        tickCountdown(txtCountdown)
    }

    private fun addLine(txtLog: TextView) {
        if (lineIndex < logLines.size) {
            txtLog.append(logLines[lineIndex] + "\n")
            lineIndex++
            handler.postDelayed({ addLine(txtLog) }, 900)
        } else {
            lineIndex = 0
            handler.postDelayed({ addLine(txtLog) }, 900)
        }
    }

    private fun tickCountdown(txtCountdown: TextView) {
        txtCountdown.text = countdown.toString()
        if (countdown > 0) {
            countdown--
            handler.postDelayed({ tickCountdown(txtCountdown) }, 1000)
        } else {
            countdown = 10
            handler.postDelayed({ tickCountdown(txtCountdown) }, 1000)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
