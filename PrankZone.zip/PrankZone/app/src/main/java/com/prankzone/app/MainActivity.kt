package com.prankzone.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.prankzone.app.pranks.*

class MainActivity : AppCompatActivity() {

    private var pendingPrank: Prank? = null

    private val pranks by lazy {
        listOf(
        Prank(getStr(R.string.prank_virus_title), getStr(R.string.prank_virus_desc), FakeVirusActivity::class.java),
        Prank(getStr(R.string.prank_call_title), getStr(R.string.prank_call_desc), FakeCallActivity::class.java),
        Prank(getStr(R.string.prank_crash_title), getStr(R.string.prank_crash_desc), FakeCrashActivity::class.java),
        Prank(getStr(R.string.prank_hack_title), getStr(R.string.prank_hack_desc), FakeHackActivity::class.java),
        Prank(getStr(R.string.prank_strobe_title), getStr(R.string.prank_strobe_desc), StrobeFlashActivity::class.java, needsCamera = true),
        Prank(getStr(R.string.prank_siren_title), getStr(R.string.prank_siren_desc), SirenActivity::class.java),
        Prank(getStr(R.string.prank_update_title), getStr(R.string.prank_update_desc), FakeUpdateActivity::class.java),
        Prank(getStr(R.string.prank_cracked_title), getStr(R.string.prank_cracked_desc), CrackedScreenActivity::class.java),
        Prank(getStr(R.string.prank_battery_title), getStr(R.string.prank_battery_desc), LowBatteryActivity::class.java),
        Prank(getStr(R.string.prank_shock_title), getStr(R.string.prank_shock_desc), ShockButtonActivity::class.java)
        )
    }

    private fun getStr(id: Int): String = resources.getString(id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler = findViewById<RecyclerView>(R.id.recyclerPranks)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = PrankAdapter(pranks) { prank -> launchPrank(prank) }
    }

    private fun launchPrank(prank: Prank) {
        if (prank.needsCamera && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingPrank = prank
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
            return
        }
        startActivity(Intent(this, prank.activityClass))
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA) {
            val prank = pendingPrank
            pendingPrank = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                prank?.let { startActivity(Intent(this, it.activityClass)) }
            } else {
                Toast.makeText(this, getString(R.string.permission_needed), Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val REQUEST_CAMERA = 100
    }
}
