package com.prankzone.app.pranks

import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity

/**
 * Toutes les activités de prank héritent de cette classe.
 * Elle fournit un geste commun pour quitter la blague : un appui long de 3 secondes
 * n'importe où sur l'écran racine. Cela évite qu'un prank ne "bloque" la personne
 * indéfiniment sans issue.
 */
abstract class BasePrankActivity : AppCompatActivity() {

    private val exitHandler = Handler(Looper.getMainLooper())
    private val exitRunnable = Runnable { finish() }

    protected fun setupExitGesture(rootView: View) {
        rootView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> exitHandler.postDelayed(exitRunnable, 3000)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> exitHandler.removeCallbacks(exitRunnable)
            }
            false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        exitHandler.removeCallbacksAndMessages(null)
    }
}
