package com.prankzone.app.pranks

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.view.animation.LinearInterpolator
import com.prankzone.app.R

class GhostHauntActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var animator: ValueAnimator? = null

    private val messages = listOf(
        "👻 Je suis derrière toi...",
        "Tu ne peux pas m'échapper",
        "Ton téléphone est hanté",
        "Continue de scroller...",
        "Je vois ce que tu fais"
    )
    private var index = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ghost_haunt)

        val root = findViewById<android.view.View>(R.id.rootGhost)
        setupExitGesture(root)

        animator = ValueAnimator.ofObject(ArgbEvaluator(), 0xFF0F0F1A.toInt(), 0xFF1C1C2E.toInt()).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { root.setBackgroundColor(it.animatedValue as Int) }
            start()
        }

        val txtMsg = findViewById<TextView>(R.id.txtGhostMsg)
        cycleMessages(txtMsg)
    }

    private fun cycleMessages(txtMsg: TextView) {
        txtMsg.text = messages[index % messages.size]
        index++
        handler.postDelayed({ cycleMessages(txtMsg) }, 2200)
    }

    override fun onDestroy() {
        super.onDestroy()
        animator?.cancel()
        handler.removeCallbacksAndMessages(null)
    }
}
