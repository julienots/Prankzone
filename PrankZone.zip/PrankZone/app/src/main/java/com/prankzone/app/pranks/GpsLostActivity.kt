package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import com.prankzone.app.R

class GpsLostActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gps_lost)

        val root = findViewById<android.view.View>(R.id.rootGps)
        setupExitGesture(root)

        val txtStatus = findViewById<TextView>(R.id.txtGpsStatus)
        val spinner = findViewById<android.widget.ProgressBar>(R.id.progressGps)

        handler.postDelayed({
            spinner.visibility = android.view.View.GONE
            txtStatus.text = "❌ Signal GPS perdu\nPosition inconnue"
        }, 3500)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
