package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import com.prankzone.app.R

class FakeCrashActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var percent = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fake_crash)
        setupExitGesture(findViewById(android.R.id.content))

        val txtPercent = findViewById<TextView>(R.id.txtCrashPercent)
        tick(txtPercent)
    }

    private fun tick(txtPercent: TextView) {
        if (percent < 47) {
            percent += (1..3).random()
        }
        // Se bloque volontairement autour de 47% pour l'effet comique, comme un vrai plantage
        if (percent > 47) percent = 47
        txtPercent.text = "$percent% terminé"
        if (percent < 47) {
            handler.postDelayed({ tick(txtPercent) }, 350)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
