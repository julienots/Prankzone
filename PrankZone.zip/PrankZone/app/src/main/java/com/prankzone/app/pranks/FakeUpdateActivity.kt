package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import android.widget.TextView
import com.prankzone.app.R

class FakeUpdateActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var percent = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fake_update)
        setupExitGesture(findViewById(android.R.id.content))

        val progressBar = findViewById<ProgressBar>(R.id.progressUpdate)
        val txtPercent = findViewById<TextView>(R.id.txtUpdatePercent)
        tick(progressBar, txtPercent)
    }

    private fun tick(progressBar: ProgressBar, txtPercent: TextView) {
        if (percent < 99) {
            percent++
            progressBar.progress = percent
            txtPercent.text = "$percent%"
            val delay = if (percent > 90) 400L else 60L
            handler.postDelayed({ tick(progressBar, txtPercent) }, delay)
        }
        // Reste bloqué à 99% indéfiniment, comme une vraie mise à jour capricieuse
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
