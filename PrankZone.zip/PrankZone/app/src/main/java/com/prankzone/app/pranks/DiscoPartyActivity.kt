package com.prankzone.app.pranks

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.prankzone.app.R

class DiscoPartyActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var hue = 0f
    private var running = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_disco_party)

        val root = findViewById<android.view.View>(R.id.rootDisco)
        setupExitGesture(root)

        cycleColor(root)
    }

    private fun cycleColor(root: android.view.View) {
        if (!running) return
        hue = (hue + 35f) % 360f
        root.setBackgroundColor(Color.HSVToColor(floatArrayOf(hue, 0.85f, 0.9f)))
        handler.postDelayed({ cycleColor(root) }, 120)
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        handler.removeCallbacksAndMessages(null)
    }
}
