package com.prankzone.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PrankAdapter(
    private val pranks: List<Prank>,
    private val onClick: (Prank) -> Unit
) : RecyclerView.Adapter<PrankAdapter.PrankViewHolder>() {

    class PrankViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.txtTitle)
        val desc: TextView = view.findViewById(R.id.txtDesc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PrankViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_prank, parent, false)
        return PrankViewHolder(view)
    }

    override fun onBindViewHolder(holder: PrankViewHolder, position: Int) {
        val prank = pranks[position]
        holder.title.text = prank.title
        holder.desc.text = prank.description
        holder.itemView.setOnClickListener { onClick(prank) }
    }

    override fun getItemCount(): Int = pranks.size
}
