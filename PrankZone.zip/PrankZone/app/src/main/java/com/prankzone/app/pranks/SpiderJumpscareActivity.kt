package com.prankzone.app.pranks

import android.animation.ValueAnimator
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.animation.OvershootInterpolator
import com.prankzone.app.R

class SpiderJumpscareActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spider_jumpscare)

        val root = findViewById<android.view.View>(R.id.rootSpider)
        val spider = findViewById<android.widget.TextView>(R.id.txtSpider)
        val hint = findViewById<android.widget.TextView>(R.id.txtSpiderHint)
        setupExitGesture(root)

        hint.alpha = 0f
        spider.scaleX = 0f
        spider.scaleY = 0f

        handler.postDelayed({
            spider.animate()
                .scaleX(1f).scaleY(1f)
                .setDuration(350)
                .setInterpolator(OvershootInterpolator())
                .start()
            vibrateBurst()
            wiggle(spider)
            hint.animate().alpha(1f).setStartDelay(500).setDuration(400).start()
        }, 1200)
    }

    private fun wiggle(view: android.view.View) {
        val anim = ValueAnimator.ofFloat(-12f, 12f)
        anim.duration = 90
        anim.repeatMode = ValueAnimator.REVERSE
        anim.repeatCount = 6
        anim.addUpdateListener { view.rotation = it.animatedValue as Float }
        anim.start()
    }

    private fun vibrateBurst() {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 100, 50, 100, 50, 200)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
