package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import android.widget.TextView
import com.prankzone.app.R

class StorageFullActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var percent = 87

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_storage_full)
        setupExitGesture(findViewById(android.R.id.content))

        val progressBar = findViewById<ProgressBar>(R.id.progressStorage)
        val txtPercent = findViewById<TextView>(R.id.txtStoragePercent)
        val txtWarning = findViewById<TextView>(R.id.txtStorageWarning)
        tick(progressBar, txtPercent, txtWarning)
    }

    private fun tick(progressBar: ProgressBar, txtPercent: TextView, txtWarning: TextView) {
        if (percent < 100) {
            percent++
            progressBar.progress = percent
            txtPercent.text = "$percent%"
            if (percent >= 99) txtWarning.text = "⚠️ Stockage plein ! Impossible de prendre plus de photos."
            handler.postDelayed({ tick(progressBar, txtPercent, txtWarning) }, 250)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
