package com.prankzone.app.pranks

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import com.prankzone.app.R

class SlowChargeActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val estimates = listOf(
        "2 heures restantes",
        "17 heures restantes",
        "1 jour et 4 heures restantes",
        "3 jours restantes... recalcul en cours",
        "Temps restant : indéterminé ⚡"
    )
    private var index = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slow_charge)
        setupExitGesture(findViewById(android.R.id.content))

        val txtEstimate = findViewById<TextView>(R.id.txtChargeEstimate)
        cycle(txtEstimate)
    }

    private fun cycle(txtEstimate: TextView) {
        txtEstimate.text = estimates[index % estimates.size]
        index++
        handler.postDelayed({ cycle(txtEstimate) }, 2500)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
