package com.prankzone.app.pranks

import android.os.Bundle
import com.prankzone.app.R

class CrackedScreenActivity : BasePrankActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cracked_screen)
        setupExitGesture(findViewById(android.R.id.content))
    }
}
