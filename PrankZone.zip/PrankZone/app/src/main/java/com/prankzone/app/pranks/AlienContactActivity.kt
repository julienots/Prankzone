package com.prankzone.app.pranks

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.LinearInterpolator
import android.widget.TextView
import com.prankzone.app.R

class AlienContactActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var animator: ValueAnimator? = null

    private val messages = listOf(
        "📡 Signal extraterrestre détecté",
        "Origine : inconnue",
        "Distance : 4.2 années-lumière",
        "Décodage du message...",
        "Ils savent que tu es là 👽"
    )
    private var index = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alien_contact)

        val root = findViewById<android.view.View>(R.id.rootAlien)
        setupExitGesture(root)

        animator = ValueAnimator.ofObject(ArgbEvaluator(), 0xFF001A0F.toInt(), 0xFF00552E.toInt()).apply {
            duration = 700
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { root.setBackgroundColor(it.animatedValue as Int) }
            start()
        }

        val txtInfo = findViewById<TextView>(R.id.txtAlienInfo)
        cycleMessages(txtInfo)
    }

    private fun cycleMessages(txtInfo: TextView) {
        txtInfo.text = messages[index % messages.size]
        index++
        handler.postDelayed({ cycleMessages(txtInfo) }, 1800)
    }

    override fun onDestroy() {
        super.onDestroy()
        animator?.cancel()
        handler.removeCallbacksAndMessages(null)
    }
}
