package com.prankzone.app.pranks

import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.Toast
import com.prankzone.app.R

class ShockButtonActivity : BasePrankActivity() {

    private var dodgeCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shock_button)

        val root = findViewById<RelativeLayout>(R.id.rootShock)
        setupExitGesture(root)

        val button = findViewById<Button>(R.id.btnDoNotPress)

        button.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_HOVER_ENTER) {
                dodgeButton(root, view)
                true
            } else {
                false
            }
        }

        button.setOnClickListener {
            dodgeCount++
            if (dodgeCount >= 6) {
                Toast.makeText(this, "Bravo, tu as réussi à l'attraper !", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun dodgeButton(root: RelativeLayout, button: android.view.View) {
        val maxX = (root.width - button.width).coerceAtLeast(1)
        val maxY = (root.height - button.height).coerceAtLeast(1)
        val newX = (0..maxX).random().toFloat()
        val newY = (0..maxY).random().toFloat()
        button.animate().x(newX).y(newY).setDuration(150).start()
    }
}
