package com.prankzone.app.pranks

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.LinearInterpolator
import android.widget.TextView
import com.prankzone.app.R

class FakeVirusActivity : BasePrankActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var animator: ValueAnimator? = null

    private val messages = listOf(
        "Analyse du système en cours...",
        "247 fichiers infectés détectés",
        "Le virus se propage...",
        "Tentative de blocage...",
        "ALERTE : accès non autorisé détecté"
    )
    private var index = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fake_virus)

        val root = findViewById<android.view.View>(R.id.rootVirus)
        setupExitGesture(root)

        animator = ValueAnimator.ofObject(ArgbEvaluator(), 0xFFD32F2F.toInt(), 0xFF7A0000.toInt()).apply {
            duration = 400
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { root.setBackgroundColor(it.animatedValue as Int) }
            start()
        }

        val txtInfo = findViewById<TextView>(R.id.txtVirusInfo)
        cycleMessages(txtInfo)
    }

    private fun cycleMessages(txtInfo: TextView) {
        txtInfo.text = messages[index % messages.size]
        index++
        handler.postDelayed({ cycleMessages(txtInfo) }, 1600)
    }

    override fun onDestroy() {
        super.onDestroy()
        animator?.cancel()
        handler.removeCallbacksAndMessages(null)
    }
}
