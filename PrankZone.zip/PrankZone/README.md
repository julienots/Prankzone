# PrankZone

Application Android native (Kotlin) de pranks/farces à faire à ses amis.

## Pranks inclus
- Fausse alerte virus (écran rouge clignotant)
- Faux appel entrant (sonnerie + vibreur)
- Faux plantage système (écran bleu)
- Faux piratage (terminal + compte à rebours)
- Stroboscope flash (utilise le flash de la caméra — demande la permission CAMERA)
- Sirène sonore + vibreur
- Fausse mise à jour bloquée à 99%
- Écran fissuré (effet visuel)
- Batterie critique qui chute vite
- Bouton "NE PAS APPUYER" qui esquive le doigt

Chaque écran de prank se quitte avec un appui long de 3 secondes n'importe où sur l'écran.

## Build
Le projet est compilé en APK via GitHub Actions (voir `.github/workflows`), pas de build local nécessaire.
